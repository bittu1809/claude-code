'use strict';
// A small, dependency-free Markdown renderer for model output.
// Everything is HTML-escaped before any markup is added, so model text can
// never inject tags or scripts into the window.

(function () {
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  function inline(src) {
    const codes = [];
    let s = src.replace(/`([^`\n]+)`/g, (_m, c) => {
      codes.push(c);
      return `\u0000${codes.length - 1}\u0000`;
    });
    s = esc(s);
    s = s.replace(/\*\*([^*\n]+?)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/(^|[\s(>])\*([^*\s][^*\n]*?)\*(?=[\s).,;:!?<]|$)/g, '$1<em>$2</em>');
    s = s.replace(/(^|[\s(>])_([^_\s][^_\n]*?)_(?=[\s).,;:!?<]|$)/g, '$1<em>$2</em>');
    s = s.replace(/~~([^~\n]+?)~~/g, '<del>$1</del>');
    s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noreferrer">$1</a>');
    s = s.replace(/\u0000(\d+)\u0000/g, (_m, i) => `<code>${esc(codes[+i])}</code>`);
    return s.replace(/\n/g, '<br>');
  }

  const LIST = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/;
  const TABLE_SEP = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;

  function cells(line) {
    return line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim());
  }

  function renderList(items, pos, indent) {
    const ordered = items[pos].ordered;
    let html = ordered ? `<ol start="${items[pos].start}">` : '<ul>';
    while (pos < items.length && items[pos].indent >= indent) {
      if (items[pos].indent > indent) {
        const [h, p] = renderList(items, pos, items[pos].indent);
        html += h;
        pos = p;
        continue;
      }
      let text = items[pos].text;
      let cls = '';
      const task = /^\[([ xX])\]\s+/.exec(text);
      if (task) {
        text = text.slice(task[0].length);
        cls = task[1] === ' ' ? ' class="task"' : ' class="task done"';
      }
      html += `<li${cls}>${inline(text)}`;
      pos++;
      if (pos < items.length && items[pos].indent > indent) {
        const [h, p] = renderList(items, pos, items[pos].indent);
        html += h;
        pos = p;
      }
      html += '</li>';
    }
    return [html + (ordered ? '</ol>' : '</ul>'), pos];
  }

  function render(md) {
    const lines = String(md || '').replace(/\r\n/g, '\n').split('\n');
    let html = '';
    let i = 0;
    while (i < lines.length) {
      const line = lines[i];

      // fenced code
      const fence = /^\s*(```+|~~~+)\s*([\w+#.-]*)[^`]*$/.exec(line);
      if (fence) {
        const body = [];
        i++;
        while (i < lines.length && !new RegExp(`^\\s*${fence[1][0]}{${fence[1].length},}\\s*$`).test(lines[i])) body.push(lines[i++]);
        i++; // closing fence (or end of text while still streaming)
        html += `<div class="code"><div class="code-head"><span>${esc(fence[2] || 'text')}</span><button type="button" class="copy" data-copy>Copy</button></div><pre><code>${esc(body.join('\n'))}</code></pre></div>`;
        continue;
      }

      if (!line.trim()) {
        i++;
        continue;
      }

      const h = /^(#{1,6})\s+(.*?)\s*#*\s*$/.exec(line);
      if (h) {
        html += `<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`;
        i++;
        continue;
      }

      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) {
        html += '<hr>';
        i++;
        continue;
      }

      if (/^\s*>/.test(line)) {
        const q = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) q.push(lines[i++].replace(/^\s*>\s?/, ''));
        html += `<blockquote>${render(q.join('\n'))}</blockquote>`;
        continue;
      }

      if (line.includes('|') && i + 1 < lines.length && TABLE_SEP.test(lines[i + 1])) {
        const head = cells(line);
        i += 2;
        let t = `<div class="table-wrap"><table><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join('')}</tr></thead><tbody>`;
        while (i < lines.length && lines[i].includes('|') && lines[i].trim()) {
          const row = cells(lines[i++]);
          t += `<tr>${head.map((_c, k) => `<td>${inline(row[k] || '')}</td>`).join('')}</tr>`;
        }
        html += t + '</tbody></table></div>';
        continue;
      }

      if (LIST.test(line)) {
        const items = [];
        while (i < lines.length) {
          const m = LIST.exec(lines[i]);
          if (m) {
            const ordered = /\d/.test(m[2]);
            items.push({ indent: m[1].replace(/\t/g, '    ').length, ordered, start: ordered ? parseInt(m[2], 10) : 1, text: m[3] });
            i++;
          } else if (lines[i].trim() && /^\s{2,}/.test(lines[i]) && !/^\s*(```|~~~)/.test(lines[i])) {
            items[items.length - 1].text += '\n' + lines[i].trim(); // continuation of the item above
            i++;
          } else if (!lines[i].trim() && i + 1 < lines.length && LIST.test(lines[i + 1])) {
            i++; // blank line between items
          } else {
            break;
          }
        }
        let pos = 0;
        while (pos < items.length) {
          const [h2, p] = renderList(items, pos, items[pos].indent);
          html += h2;
          pos = p;
        }
        continue;
      }

      // paragraph
      const para = [];
      while (
        i < lines.length && lines[i].trim() &&
        !/^\s*(```|~~~)/.test(lines[i]) && !/^#{1,6}\s/.test(lines[i]) && !/^\s*>/.test(lines[i]) && !LIST.test(lines[i])
      ) {
        para.push(lines[i++]);
      }
      if (!para.length) para.push(lines[i++]); // always make progress
      html += `<p>${inline(para.join('\n'))}</p>`;
    }
    return html;
  }

  window.renderMarkdown = render;
  window.escapeHtml = esc;
})();
