'use strict';
/* global api, renderMarkdown */

const $ = (sel) => document.querySelector(sel);
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
};

const MODES = ['chat', 'plan', 'act'];
const MODE_INFO = {
  chat: { name: 'Chat', hint: 'Talk it through. No access to your files.', placeholder: 'Ask anything…' },
  plan: { name: 'Plan', hint: 'Reads your project and writes a plan. Changes nothing.', placeholder: 'Describe what you want built or changed…' },
  act: { name: 'Act', hint: 'Edits files and runs commands. Asks before each one.', placeholder: 'Tell the agent what to do…' },
};
const TOOL_VERB = {
  list_dir: 'List', read_file: 'Read', find_files: 'Find', search: 'Search',
  write_file: 'Write', edit_file: 'Edit', run_command: 'Run', background_output: 'Output',
};

const state = {
  settings: null,
  sessions: [],
  session: null,
  mode: 'chat',
  running: false,
  live: null, // { el, text } assistant message being streamed
  tools: new Map(), // callId -> tool row
};

const transcript = $('#transcript');
const input = $('#input');
const sendBtn = $('#send');

// ------------------------------------------------------------------ utilities

function cleanError(e) {
  return String((e && e.message) || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
}

function baseName(p) {
  return p ? p.replace(/[\\/]+$/, '').split(/[\\/]/).pop() : '';
}

function nearBottom() {
  return transcript.scrollHeight - transcript.scrollTop - transcript.clientHeight < 120;
}

function scrollDown(force) {
  if (force || scrollDown.stick) transcript.scrollTop = transcript.scrollHeight;
}
scrollDown.stick = true;
transcript.addEventListener('scroll', () => {
  scrollDown.stick = nearBottom();
});

function append(node) {
  const status = $('#status-row');
  if (status) transcript.insertBefore(node, status);
  else transcript.appendChild(node);
  scrollDown();
  return node;
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = el('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
}

// --------------------------------------------------------------- mode + chrome

function setMode(mode, persist = true) {
  if (!MODES.includes(mode)) mode = 'chat';
  state.mode = mode;
  document.body.dataset.mode = mode;
  for (const b of document.querySelectorAll('.mode')) {
    const on = b.dataset.mode === mode;
    b.classList.toggle('on', on);
    b.setAttribute('aria-checked', String(on));
  }
  $('#mode-hint').textContent = MODE_INFO[mode].hint;
  input.placeholder = MODE_INFO[mode].placeholder;
  if (persist) api.saveSettings({ lastMode: mode }).catch(() => {});
}

function cycleMode() {
  setMode(MODES[(MODES.indexOf(state.mode) + 1) % MODES.length]);
}

function activeProvider() {
  return state.settings.providers[state.settings.provider];
}

function providerReady() {
  const p = activeProvider();
  return !!p && !!p.model && (!p.needsKey || p.hasKey) && !!p.baseUrl;
}

function renderChrome() {
  const p = activeProvider();
  const chip = $('#model-chip');
  chip.textContent = providerReady() ? `${p.label.replace(/ \(.*/, '')} · ${p.model}` : 'Set up a model';
  chip.classList.toggle('warn', !providerReady());

  const ws = state.session && state.session.workspace;
  $('#folder-name').textContent = ws ? baseName(ws) : 'Choose a folder…';
  $('#folder-path').textContent = ws || '';
  $('#folder-btn').title = ws ? `${ws}\nClick to choose a different folder` : 'Choose the folder the agent works in';
  $('#title').textContent = state.session ? state.session.title : 'New session';
}

function renderSessions() {
  const box = $('#sessions');
  box.textContent = '';
  if (!state.sessions.length) {
    box.appendChild(el('div', 'muted small pad', 'No saved sessions yet.'));
    return;
  }
  for (const s of state.sessions) {
    const row = el('div', 'session' + (state.session && s.id === state.session.id ? ' on' : ''));
    const main = el('button', 'session-main');
    main.appendChild(el('span', 'session-title', s.title || 'Untitled'));
    main.appendChild(el('span', 'session-sub muted', baseName(s.workspace) || 'no folder'));
    main.addEventListener('click', () => openSession(s.id));
    const del = el('button', 'session-del', '×');
    del.title = 'Delete session';
    del.setAttribute('aria-label', `Delete session ${s.title}`);
    del.addEventListener('click', async () => {
      if (state.running) return;
      if (!confirm(`Delete "${s.title}"? This only removes the conversation, not your files.`)) return;
      state.sessions = await api.deleteSession(s.id);
      if (state.session && state.session.id === s.id) await newSession();
      else renderSessions();
    });
    row.append(main, del);
    box.appendChild(row);
  }
}

function setRunning(on) {
  state.running = on;
  document.body.classList.toggle('running', on);
  sendBtn.textContent = on ? 'Stop' : 'Send';
  sendBtn.classList.toggle('danger', on);
  $('#new-session').disabled = on;
  if (!on) setStatus(null);
}

function setStatus(text) {
  let row = $('#status-row');
  if (!text) {
    if (row) row.remove();
    return;
  }
  if (!row) {
    row = el('div', 'status-row');
    row.id = 'status-row';
    row.append(el('span', 'spinner'), el('span', 'status-text'));
    transcript.appendChild(row);
  }
  row.querySelector('.status-text').textContent = text;
  scrollDown();
}

// ----------------------------------------------------------------- transcript

function renderEmpty() {
  const box = el('div', 'empty');
  box.id = 'empty';
  box.appendChild(el('h1', '', 'What are we building?'));
  box.appendChild(el('p', 'muted', 'Pick a mode, describe what you want, and let the agent do the typing.'));
  const cards = el('div', 'cards');
  const blurbs = {
    chat: 'Ask questions and think out loud. The agent cannot see or touch your project.',
    plan: 'The agent explores your project read-only and comes back with a step-by-step plan for you to approve.',
    act: 'The agent writes files and runs commands in your project folder, and asks you before each change.',
  };
  for (const m of MODES) {
    const c = el('button', `card card-${m}`);
    c.appendChild(el('span', 'card-name', MODE_INFO[m].name));
    c.appendChild(el('span', 'card-text', blurbs[m]));
    c.addEventListener('click', () => {
      setMode(m);
      input.focus();
    });
    cards.appendChild(c);
  }
  box.appendChild(cards);

  const todo = el('div', 'setup');
  if (!providerReady()) {
    const b = el('button', 'btn', 'Add an API key and pick a model');
    b.addEventListener('click', openSettings);
    todo.appendChild(b);
  }
  if (!state.session || !state.session.workspace) {
    const b = el('button', 'btn', 'Choose a project folder');
    b.addEventListener('click', pickFolder);
    todo.appendChild(b);
  }
  if (todo.children.length) box.appendChild(todo);
  transcript.appendChild(box);
}

function clearEmpty() {
  const e = $('#empty');
  if (e) e.remove();
  const bar = $('.planbar');
  if (bar) bar.remove();
}

function addUser(text, mode) {
  clearEmpty();
  const row = el('div', 'row user');
  const bubble = el('div', 'bubble');
  if (mode) bubble.appendChild(el('span', `tag tag-${mode}`, MODE_INFO[mode] ? MODE_INFO[mode].name : mode));
  bubble.appendChild(el('div', 'user-text', text));
  row.appendChild(bubble);
  append(row);
  scrollDown(true);
}

function addAssistant(text) {
  const row = el('div', 'row assistant');
  const md = el('div', 'md');
  md.innerHTML = renderMarkdown(text);
  row.appendChild(md);
  append(row);
  return { el: md, text };
}

function addNote(text, kind) {
  clearEmpty();
  append(el('div', `note ${kind || ''}`, text));
}

function toolTarget(name, input) {
  switch (name) {
    case 'list_dir': return input.path || '.';
    case 'read_file': return input.path + (input.offset ? `:${input.offset}` : '');
    case 'find_files': return input.pattern;
    case 'search': return `"${input.pattern}"${input.path && input.path !== '.' ? ` in ${input.path}` : ''}`;
    case 'write_file':
    case 'edit_file': return input.path;
    case 'run_command': return input.command;
    case 'background_output': return input.id + (input.kill ? ' (stop)' : '');
    default: return '';
  }
}

function addTool(callId, name, inputObj) {
  const input = inputObj || {};
  const box = el('details', 'tool running');
  const sum = el('summary');
  sum.append(
    el('span', 'dot'),
    el('span', 'tname', TOOL_VERB[name] || name),
    el('span', 'targ', String(toolTarget(name, input) || '')),
    el('span', 'tmeta'),
  );
  const body = el('div', 'tbody');
  box.append(sum, body);
  append(box);
  const t = { box, body, name, meta: sum.querySelector('.tmeta'), out: null, previewEl: null };
  state.tools.set(callId, t);
  return t;
}

function renderPreview(t, preview) {
  if (!preview || t.previewEl) return;
  let node;
  if (preview.kind === 'diff') {
    node = el('div', 'diff');
    const head = el('div', 'diff-head');
    head.append(el('span', '', preview.isNew ? 'New file' : 'Changes'), el('span', 'plus', `+${preview.added}`), el('span', 'minus', `−${preview.removed}`));
    node.appendChild(head);
    const pre = el('pre');
    for (const line of (preview.diff || '(no textual changes)').split('\n')) {
      const c = line[0];
      const cls = c === '+' ? 'add' : c === '-' ? 'del' : c === '@' ? 'hunk' : '';
      pre.appendChild(el('span', `dl ${cls}`, line || ' '));
    }
    node.appendChild(pre);
  } else if (preview.kind === 'command') {
    node = el('pre', 'cmd', `$ ${preview.command}${preview.background ? '   (runs in the background)' : ''}`);
  }
  if (node) {
    t.previewEl = node;
    t.body.prepend(node);
    t.box.open = true;
  }
}

function toolOutput(t) {
  if (!t.out) {
    t.out = el('pre', 'out');
    t.body.appendChild(t.out);
  }
  return t.out;
}

function finishTool(t, output, isError) {
  t.box.classList.remove('running', 'waiting');
  const denied = isError && /^The user declined/.test(output || '');
  t.box.classList.add(denied ? 'denied' : isError ? 'error' : 'ok');
  const text = String(output || '');
  const lines = text ? text.split('\n').length : 0;
  if (denied) t.meta.textContent = 'declined';
  else if (isError) t.meta.textContent = 'failed';
  else if (t.name === 'read_file') t.meta.textContent = `${lines} lines`;
  else if (t.name === 'search' || t.name === 'find_files') t.meta.textContent = /^No (matches|files)/.test(text) ? 'nothing' : `${lines} results`;
  else if (t.name === 'list_dir') t.meta.textContent = `${lines} entries`;
  else if (t.name === 'run_command') t.meta.textContent = (/\[exit code (\d+)\]\s*$/.exec(text) || [])[1] === '0' ? 'exit 0' : 'done';
  else t.meta.textContent = 'done';

  const out = toolOutput(t);
  out.textContent = text;
  if (isError && !denied) t.box.open = true;
  if (t.name === 'run_command' && lines <= 14) t.box.open = true;
}

function addApproval(t, ev) {
  renderPreview(t, ev.preview);
  t.box.classList.add('waiting');
  t.box.open = true;
  const card = el('div', 'approval');
  const isCmd = ev.name === 'run_command';
  card.appendChild(el('div', 'approval-q', isCmd ? 'Run this command?' : ev.preview && ev.preview.isNew ? 'Create this file?' : 'Apply this change?'));
  const row = el('div', 'approval-row');
  const allow = el('button', 'btn primary', 'Allow');
  const always = el('button', 'btn', isCmd ? 'Always allow this command' : 'Allow all edits this session');
  const deny = el('button', 'btn', 'Deny');
  const why = el('input', 'approval-why');
  why.type = 'text';
  why.placeholder = 'Optional: tell the agent what to do instead';
  row.append(allow, always, deny);
  card.append(row, why);
  t.body.appendChild(card);
  setStatus('Waiting for your approval…');
  scrollDown(true);

  const answer = async (decision) => {
    card.remove();
    t.box.classList.remove('waiting');
    setStatus(decision === 'deny' ? 'Thinking…' : isCmd ? 'Running command…' : 'Writing file…');
    await api.respond({ id: ev.id, decision, feedback: why.value });
  };
  allow.addEventListener('click', () => answer('allow'));
  always.addEventListener('click', () => answer('always'));
  deny.addEventListener('click', () => answer('deny'));
  why.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      answer('deny');
    }
  });
}

function addPlanBar() {
  const bar = el('div', 'planbar');
  bar.appendChild(el('span', '', 'Happy with the plan? Approve it to switch to Act mode and build it, or reply to keep refining.'));
  const go = el('button', 'btn primary', 'Approve plan and build');
  go.addEventListener('click', () => {
    setMode('act');
    submit('The plan is approved. Carry it out now.');
  });
  bar.appendChild(go);
  append(bar);
}

/** Rebuild the transcript from a saved session. */
function renderHistory(messages) {
  transcript.textContent = '';
  state.tools.clear();
  state.live = null;
  if (!messages.length) {
    renderEmpty();
    return;
  }
  for (const m of messages) {
    if (m.role === 'user') addUser(m.content, m.mode);
    else if (m.role === 'assistant') {
      if (m.text && m.text.trim()) addAssistant(m.text);
      for (const c of m.toolCalls || []) addTool(c.id, c.name, c.input);
    } else if (m.role === 'tool') {
      for (const r of m.results) {
        const t = state.tools.get(r.id);
        if (!t) continue;
        renderPreview(t, r.preview);
        finishTool(t, r.output, r.isError);
        if (r.preview && r.preview.kind === 'diff') t.box.open = false;
      }
    }
  }
  for (const t of state.tools.values()) t.box.classList.remove('running');
  scrollDown(true);
}

// --------------------------------------------------------------- agent events

let renderQueued = false;
function queueRender() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => {
    renderQueued = false;
    if (state.live) {
      state.live.el.innerHTML = renderMarkdown(state.live.text);
      scrollDown();
    }
  });
}

function onAgentEvent(ev) {
  if (!state.session || ev.sessionId !== state.session.id) return;
  switch (ev.type) {
    case 'text':
      if (!state.live) {
        state.live = addAssistant('');
        setStatus('Writing…');
      }
      state.live.text += ev.delta;
      queueRender();
      break;
    case 'tool_pending':
      setStatus(`Preparing ${(TOOL_VERB[ev.name] || ev.name).toLowerCase()}…`);
      break;
    case 'assistant_end':
      if (state.live) state.live.el.innerHTML = renderMarkdown(state.live.text);
      state.live = null;
      break;
    case 'tool_start':
      addTool(ev.callId, ev.name, ev.input);
      setStatus(ev.name === 'run_command' ? 'Preparing command…' : 'Working…');
      break;
    case 'tool_preview': {
      const t = state.tools.get(ev.callId);
      if (t) renderPreview(t, ev.preview);
      break;
    }
    case 'approval': {
      const t = state.tools.get(ev.callId);
      if (t) addApproval(t, ev);
      break;
    }
    case 'tool_output': {
      const t = state.tools.get(ev.callId);
      if (t) {
        const out = toolOutput(t);
        out.textContent = (out.textContent + ev.chunk).slice(-20000);
        t.box.open = true;
        out.scrollTop = out.scrollHeight;
        scrollDown();
      }
      break;
    }
    case 'tool_end': {
      const t = state.tools.get(ev.callId);
      if (t) finishTool(t, ev.output, ev.isError);
      setStatus('Thinking…');
      break;
    }
    case 'notice':
      addNote(ev.message, 'info');
      break;
    case 'error':
      addNote(ev.message, 'error');
      break;
    case 'done': {
      const wasPlan = state.mode === 'plan';
      setRunning(false);
      for (const t of state.tools.values()) t.box.classList.remove('running', 'waiting');
      for (const c of document.querySelectorAll('.approval')) c.remove();
      if (ev.stopped) addNote('Stopped.', 'info');
      else if (wasPlan && !ev.failed) addPlanBar();
      input.focus();
      break;
    }
    default:
  }
}

// -------------------------------------------------------------------- actions

async function submit(override) {
  const text = (override !== undefined ? override : input.value).trim();
  if (!text || state.running) return;
  if (!providerReady()) {
    openSettings();
    return;
  }
  if (state.mode !== 'chat' && !state.session.workspace) {
    if (!(await pickFolder())) return;
  }
  if (override === undefined) {
    input.value = '';
    autoSize();
  }
  if (!state.session.messagesSent) {
    state.session.title = text.replace(/\s+/g, ' ').slice(0, 60);
    state.session.messagesSent = true;
    renderChrome();
  }
  addUser(text, state.mode);
  setRunning(true);
  setStatus('Thinking…');
  try {
    await api.send({ sessionId: state.session.id, text, mode: state.mode });
  } catch (e) {
    addNote(cleanError(e), 'error');
    setRunning(false);
  }
}

async function pickFolder() {
  if (state.running) return false;
  const dir = await api.pickWorkspace();
  if (!dir) return false;
  state.session.workspace = dir;
  state.settings.lastWorkspace = dir;
  await api.setWorkspace({ id: state.session.id, workspace: dir });
  renderChrome();
  if ($('#empty')) renderHistory([]);
  return true;
}

async function newSession() {
  if (state.running) return;
  const s = await api.createSession(state.settings.lastWorkspace || '');
  state.session = s;
  renderHistory([]);
  renderChrome();
  renderSessions();
  input.focus();
}

async function openSession(id) {
  if (state.running || (state.session && state.session.id === id)) return;
  try {
    const s = await api.loadSession(id);
    s.messagesSent = s.messages.length > 0;
    state.session = s;
    const lastUser = [...s.messages].reverse().find((m) => m.role === 'user' && m.mode);
    if (lastUser) setMode(lastUser.mode, false);
    renderHistory(s.messages);
    renderChrome();
    renderSessions();
  } catch (e) {
    addNote(cleanError(e), 'error');
  }
}

// ------------------------------------------------------------------- settings

const dlg = $('#settings');
let draft = null;

function loadDraftFields() {
  const id = $('#set-provider').value;
  const p = draft.providers[id];
  const key = $('#set-key');
  key.value = p.newKey || '';
  key.placeholder = p.hasKey ? 'Saved. Leave empty to keep it.' : p.needsKey ? 'Paste your API key' : 'Not required';
  $('#set-key-note').textContent = 'Stored on this computer only, encrypted by the operating system where available.';
  $('#set-url').value = p.baseUrl || '';
  $('#set-url').placeholder = p.defaultBaseUrl || 'https://your-server/v1';
  $('#set-model').value = p.model || '';
  $('#set-model-list').hidden = true;
  $('#set-model-note').textContent = 'Click “Load models” to pick from the models your key can use.';
  $('#set-model-note').classList.remove('bad');
}

function storeDraftFields(id) {
  const p = draft.providers[id];
  p.newKey = $('#set-key').value.trim();
  p.baseUrl = $('#set-url').value.trim();
  p.model = $('#set-model').value.trim();
}

function openSettings() {
  draft = JSON.parse(JSON.stringify(state.settings));
  const sel = $('#set-provider');
  sel.textContent = '';
  for (const [id, p] of Object.entries(draft.providers)) {
    const o = el('option', '', p.label);
    o.value = id;
    sel.appendChild(o);
  }
  sel.value = draft.provider;
  sel.dataset.current = draft.provider;
  $('#set-max').value = draft.maxTokens;
  loadDraftFields();
  dlg.showModal();
}

$('#set-provider').addEventListener('change', (e) => {
  storeDraftFields(e.target.dataset.current);
  e.target.dataset.current = e.target.value;
  loadDraftFields();
});

$('#set-load').addEventListener('click', async () => {
  const id = $('#set-provider').value;
  const note = $('#set-model-note');
  const list = $('#set-model-list');
  note.classList.remove('bad');
  note.textContent = 'Loading…';
  try {
    const models = await api.listModels({ id, apiKey: $('#set-key').value, baseUrl: $('#set-url').value });
    list.textContent = '';
    const first = el('option', '', `Choose from ${models.length} models…`);
    first.value = '';
    list.appendChild(first);
    for (const m of models) {
      const o = el('option', '', m);
      o.value = m;
      list.appendChild(o);
    }
    list.hidden = false;
    if (models.includes($('#set-model').value)) list.value = $('#set-model').value;
    note.textContent = models.length ? 'Pick a model from the list, or type an id.' : 'The provider returned no models. Type a model id instead.';
  } catch (e) {
    list.hidden = true;
    note.classList.add('bad');
    note.textContent = cleanError(e);
  }
});

$('#set-model-list').addEventListener('change', (e) => {
  if (e.target.value) $('#set-model').value = e.target.value;
});

$('#set-cancel').addEventListener('click', () => dlg.close());

$('#set-save').addEventListener('click', async () => {
  const id = $('#set-provider').value;
  storeDraftFields(id);
  const patch = { provider: id, maxTokens: Number($('#set-max').value) || 16000, providers: {} };
  for (const [pid, p] of Object.entries(draft.providers)) {
    patch.providers[pid] = { baseUrl: p.baseUrl, model: p.model };
    if (p.newKey) patch.providers[pid].apiKey = p.newKey;
  }
  try {
    state.settings = await api.saveSettings(patch);
    dlg.close();
    renderChrome();
    if ($('#empty')) renderHistory([]);
  } catch (e) {
    $('#set-model-note').classList.add('bad');
    $('#set-model-note').textContent = cleanError(e);
  }
});

// --------------------------------------------------------------------- wiring

function autoSize() {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 240) + 'px';
}

input.addEventListener('input', autoSize);
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    submit();
  }
});

document.addEventListener('keydown', (e) => {
  if (dlg.open) return;
  if (e.key === 'Tab' && e.shiftKey) {
    e.preventDefault();
    if (!state.running) cycleMode();
  } else if (e.key === 'Escape' && state.running) {
    api.stop();
  }
});

sendBtn.addEventListener('click', () => (state.running ? api.stop() : submit()));
$('#new-session').addEventListener('click', newSession);
$('#folder-btn').addEventListener('click', pickFolder);
$('#settings-btn').addEventListener('click', openSettings);
$('#model-chip').addEventListener('click', openSettings);
for (const b of document.querySelectorAll('.mode')) {
  b.addEventListener('click', () => {
    if (!state.running) setMode(b.dataset.mode);
    input.focus();
  });
}

transcript.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-copy]');
  if (!btn) return;
  const code = btn.closest('.code').querySelector('code');
  copyText(code.textContent);
  btn.textContent = 'Copied';
  setTimeout(() => (btn.textContent = 'Copy'), 1200);
});

api.onEvent(onAgentEvent);
api.onSessionsChanged((list) => {
  state.sessions = list;
  renderSessions();
});

(async function start() {
  const init = await api.init();
  state.settings = init.settings;
  state.sessions = init.sessions;
  setMode(init.settings.lastMode || 'chat', false);
  await newSession();
})();
