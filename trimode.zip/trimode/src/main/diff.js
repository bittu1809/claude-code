'use strict';
// Small line-based diff used to preview file changes before the user approves them.

const MAX_CELLS = 4_000_000; // cap on LCS table size
const CONTEXT = 3;

function lcsOps(a, b) {
  const n = a.length;
  const m = b.length;
  // Trim common prefix/suffix first so the table stays small for typical edits.
  let start = 0;
  while (start < n && start < m && a[start] === b[start]) start++;
  let endA = n;
  let endB = m;
  while (endA > start && endB > start && a[endA - 1] === b[endB - 1]) {
    endA--;
    endB--;
  }
  const ops = [];
  for (let i = 0; i < start; i++) ops.push([' ', a[i]]);

  const A = a.slice(start, endA);
  const B = b.slice(start, endB);
  if (A.length * B.length > MAX_CELLS) {
    for (const l of A) ops.push(['-', l]);
    for (const l of B) ops.push(['+', l]);
  } else {
    const w = B.length + 1;
    const t = new Uint32Array((A.length + 1) * w);
    for (let i = A.length - 1; i >= 0; i--) {
      for (let j = B.length - 1; j >= 0; j--) {
        t[i * w + j] = A[i] === B[j] ? t[(i + 1) * w + j + 1] + 1 : Math.max(t[(i + 1) * w + j], t[i * w + j + 1]);
      }
    }
    let i = 0;
    let j = 0;
    while (i < A.length && j < B.length) {
      if (A[i] === B[j]) {
        ops.push([' ', A[i]]);
        i++;
        j++;
      } else if (t[(i + 1) * w + j] >= t[i * w + j + 1]) {
        ops.push(['-', A[i++]]);
      } else {
        ops.push(['+', B[j++]]);
      }
    }
    while (i < A.length) ops.push(['-', A[i++]]);
    while (j < B.length) ops.push(['+', B[j++]]);
  }
  for (let i = endA; i < n; i++) ops.push([' ', a[i]]);
  return ops;
}

/**
 * Returns { text, added, removed } where text is a unified-style diff with
 * a few lines of context around each change.
 */
function diffText(oldStr, newStr, maxLines = 400) {
  const a = oldStr === '' ? [] : oldStr.split('\n');
  const b = newStr === '' ? [] : newStr.split('\n');
  const ops = lcsOps(a, b);

  let added = 0;
  let removed = 0;
  const keep = new Uint8Array(ops.length);
  ops.forEach(([t], i) => {
    if (t === ' ') return;
    if (t === '+') added++;
    else removed++;
    for (let k = Math.max(0, i - CONTEXT); k <= Math.min(ops.length - 1, i + CONTEXT); k++) keep[k] = 1;
  });

  const out = [];
  let oldNo = 1;
  let newNo = 1;
  let lastKept = -2;
  for (let i = 0; i < ops.length; i++) {
    const [t, s] = ops[i];
    if (keep[i]) {
      if (i !== lastKept + 1) out.push(`@@ -${oldNo} +${newNo} @@`);
      out.push(t + s);
      lastKept = i;
    }
    if (t !== '+') oldNo++;
    if (t !== '-') newNo++;
  }

  let text = out.join('\n');
  if (out.length > maxLines) {
    text = out.slice(0, maxLines).join('\n') + `\n… ${out.length - maxLines} more diff lines not shown`;
  }
  return { text, added, removed };
}

module.exports = { diffText };
