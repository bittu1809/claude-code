'use strict';
// Tools the model can call. Everything is confined to the project folder.

const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { spawn } = require('child_process');
const { diffText } = require('./diff');

const IGNORE_DIRS = new Set([
  'node_modules', '.git', 'dist', 'build', 'out', '.next', '.nuxt', '.cache', '.turbo',
  '__pycache__', '.venv', 'venv', 'env', 'target', '.idea', '.gradle', 'coverage', '.pytest_cache',
]);
const MAX_OUTPUT = 30_000; // characters returned to the model per tool call
const MAX_WALK = 20_000; // files visited per search

// ---------------------------------------------------------------- definitions

const TOOLS = [
  {
    name: 'list_dir',
    kind: 'read',
    description: 'List the files and folders directly inside a directory of the project.',
    input_schema: {
      type: 'object',
      properties: { path: { type: 'string', description: 'Directory relative to the project root. Use "." for the root.' } },
      required: ['path'],
    },
  },
  {
    name: 'read_file',
    kind: 'read',
    description: 'Read a text file from the project. Returns numbered lines. Use offset/limit for large files.',
    input_schema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File path relative to the project root.' },
        offset: { type: 'integer', description: '1-based line number to start from. Default 1.' },
        limit: { type: 'integer', description: 'Maximum number of lines to return. Default 2000.' },
      },
      required: ['path'],
    },
  },
  {
    name: 'find_files',
    kind: 'read',
    description: 'Find files by glob pattern, e.g. "src/**/*.ts" or "*.json". Dependency and build folders are skipped.',
    input_schema: {
      type: 'object',
      properties: { pattern: { type: 'string', description: 'Glob pattern relative to the project root.' } },
      required: ['pattern'],
    },
  },
  {
    name: 'search',
    kind: 'read',
    description: 'Search file contents with a regular expression. Returns matching lines as path:line: text.',
    input_schema: {
      type: 'object',
      properties: {
        pattern: { type: 'string', description: 'JavaScript regular expression.' },
        path: { type: 'string', description: 'Directory or file to search in, relative to the project root. Default ".".' },
        include: { type: 'string', description: 'Optional glob to restrict which files are searched, e.g. "*.py".' },
        ignore_case: { type: 'boolean', description: 'Case-insensitive match. Default false.' },
      },
      required: ['pattern'],
    },
  },
  {
    name: 'write_file',
    kind: 'edit',
    needsApproval: true,
    description: 'Create a new file or completely overwrite an existing one. Parent folders are created automatically. For small changes to an existing file prefer edit_file.',
    input_schema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File path relative to the project root.' },
        content: { type: 'string', description: 'The full new content of the file.' },
      },
      required: ['path', 'content'],
    },
  },
  {
    name: 'edit_file',
    kind: 'edit',
    needsApproval: true,
    description: 'Replace an exact piece of text in an existing file. old_string must match the file exactly (including indentation) and must be unique unless replace_all is true. Read the file first.',
    input_schema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'File path relative to the project root.' },
        old_string: { type: 'string', description: 'Exact text to replace.' },
        new_string: { type: 'string', description: 'Replacement text.' },
        replace_all: { type: 'boolean', description: 'Replace every occurrence. Default false.' },
      },
      required: ['path', 'old_string', 'new_string'],
    },
  },
  {
    name: 'run_command',
    kind: 'exec',
    needsApproval: true,
    description: 'Run a shell command in the project root and return its output and exit code. For long-running processes such as dev servers set background to true.',
    input_schema: {
      type: 'object',
      properties: {
        command: { type: 'string', description: 'The command line to run.' },
        timeout_seconds: { type: 'integer', description: 'Kill the command after this many seconds. Default 120, max 600.' },
        background: { type: 'boolean', description: 'Start the process and return after a few seconds while it keeps running. Default false.' },
      },
      required: ['command'],
    },
  },
  {
    name: 'background_output',
    kind: 'exec',
    description: 'Read new output from a background process started with run_command, or stop it.',
    input_schema: {
      type: 'object',
      properties: {
        id: { type: 'string', description: 'Background process id, e.g. "bg1".' },
        kill: { type: 'boolean', description: 'Stop the process. Default false.' },
      },
      required: ['id'],
    },
  },
];

function toolsForMode(mode) {
  if (mode === 'act') return TOOLS;
  if (mode === 'plan') return TOOLS.filter((t) => t.kind === 'read');
  return [];
}

// -------------------------------------------------------------------- helpers

function clip(text, max = MAX_OUTPUT) {
  if (text.length <= max) return text;
  const head = Math.floor(max * 0.6);
  const tail = max - head;
  return `${text.slice(0, head)}\n\n… [${text.length - max} characters omitted] …\n\n${text.slice(-tail)}`;
}

function toPosix(p) {
  return p.split(path.sep).join('/');
}

/** Resolve a model-supplied path and refuse anything outside the project folder. */
function resolveInside(root, p) {
  if (typeof p !== 'string' || p === '') p = '.';
  const abs = path.resolve(root, p);
  const rel = path.relative(root, abs);
  if (rel.startsWith('..') || path.isAbsolute(rel)) {
    throw new Error(`Path is outside the project folder: ${p}`);
  }
  // Follow symlinks on the nearest existing ancestor so a link cannot escape either.
  let probe = abs;
  while (!fs.existsSync(probe) && probe !== path.dirname(probe)) probe = path.dirname(probe);
  try {
    const real = fs.realpathSync(probe);
    const realRoot = fs.realpathSync(root);
    const r = path.relative(realRoot, real);
    if (r.startsWith('..') || path.isAbsolute(r)) throw new Error(`Path is outside the project folder: ${p}`);
  } catch (e) {
    if (/outside the project/.test(e.message)) throw e;
  }
  return abs;
}

function globToRegExp(glob) {
  let re = '';
  let i = 0;
  let inGroup = 0;
  while (i < glob.length) {
    const c = glob[i];
    if (c === '*') {
      if (glob[i + 1] === '*') {
        if (glob[i + 2] === '/') {
          re += '(?:.*/)?';
          i += 3;
        } else {
          re += '.*';
          i += 2;
        }
        continue;
      }
      re += '[^/]*';
    } else if (c === '?') re += '[^/]';
    else if (c === '{') {
      re += '(?:';
      inGroup++;
    } else if (c === '}' && inGroup) {
      re += ')';
      inGroup--;
    } else if (c === ',' && inGroup) re += '|';
    else if ('\\^$+.()|[]'.includes(c)) re += '\\' + c;
    else re += c;
    i++;
  }
  return new RegExp(`^${re}$`, process.platform === 'win32' ? 'i' : '');
}

function makeGlobMatcher(pattern) {
  const p = toPosix(pattern.trim()).replace(/^\.\//, '');
  const re = globToRegExp(p);
  const baseOnly = !p.includes('/');
  return (relPosix) => re.test(baseOnly ? relPosix.slice(relPosix.lastIndexOf('/') + 1) : relPosix);
}

/** Depth-first walk yielding project-relative posix paths of files. */
async function* walk(root, startAbs) {
  const stack = [startAbs];
  let seen = 0;
  while (stack.length) {
    const dir = stack.pop();
    let entries;
    try {
      entries = await fsp.readdir(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    entries.sort((a, b) => (a.name < b.name ? 1 : -1));
    for (const e of entries) {
      const abs = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (!IGNORE_DIRS.has(e.name)) stack.push(abs);
      } else if (e.isFile()) {
        if (++seen > MAX_WALK) return;
        yield { abs, rel: toPosix(path.relative(root, abs)) };
      }
    }
  }
}

function looksBinary(buf) {
  const n = Math.min(buf.length, 4096);
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  return false;
}

async function readText(abs) {
  const buf = await fsp.readFile(abs);
  if (looksBinary(buf)) throw new Error('This looks like a binary file and cannot be read as text.');
  return buf.toString('utf8');
}

function stripAnsi(s) {
  // eslint-disable-next-line no-control-regex
  return s.replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, '').replace(/\r(?!\n)/g, '\n');
}

function killTree(child) {
  if (!child || child.exitCode !== null) return;
  try {
    if (process.platform === 'win32') {
      spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true });
    } else {
      process.kill(-child.pid, 'SIGTERM');
      setTimeout(() => {
        try {
          process.kill(-child.pid, 'SIGKILL');
        } catch {}
      }, 2000).unref();
    }
  } catch {
    try {
      child.kill();
    } catch {}
  }
}

// ----------------------------------------------------------------- read tools

async function listDir(root, input) {
  const abs = resolveInside(root, input.path);
  const entries = await fsp.readdir(abs, { withFileTypes: true });
  if (!entries.length) return '(empty directory)';
  const dirs = entries.filter((e) => e.isDirectory()).map((e) => e.name + '/').sort();
  const files = entries.filter((e) => !e.isDirectory()).map((e) => e.name).sort();
  return clip([...dirs, ...files].join('\n'));
}

async function readFile(root, input) {
  const abs = resolveInside(root, input.path);
  const text = (await readText(abs)).replace(/\r\n/g, '\n');
  const lines = text.split('\n');
  const offset = Math.max(1, Number.isFinite(input.offset) ? input.offset : 1);
  const limit = Math.max(1, Number.isFinite(input.limit) ? input.limit : 2000);
  const slice = lines.slice(offset - 1, offset - 1 + limit);
  if (!slice.length) return `(file has ${lines.length} lines; nothing at offset ${offset})`;
  const width = String(offset + slice.length - 1).length;
  let out = slice.map((l, i) => `${String(offset + i).padStart(width)}\t${l}`).join('\n');
  const end = offset - 1 + slice.length;
  if (end < lines.length) out += `\n… (${lines.length - end} more lines; continue with offset=${end + 1})`;
  return clip(out, 60_000);
}

async function findFiles(root, input) {
  const match = makeGlobMatcher(String(input.pattern || ''));
  const hits = [];
  for await (const f of walk(root, root)) {
    if (match(f.rel)) hits.push(f.rel);
    if (hits.length >= 500) break;
  }
  if (!hits.length) return 'No files matched.';
  hits.sort();
  return hits.join('\n') + (hits.length >= 500 ? '\n… (stopped at 500 results)' : '');
}

async function search(root, input) {
  let re;
  try {
    re = new RegExp(String(input.pattern), input.ignore_case ? 'i' : '');
  } catch (e) {
    throw new Error(`Invalid regular expression: ${e.message}`);
  }
  const startAbs = resolveInside(root, input.path || '.');
  const match = input.include ? makeGlobMatcher(String(input.include)) : null;
  const out = [];
  const stat = await fsp.stat(startAbs);
  const files = stat.isFile() ? [{ abs: startAbs, rel: toPosix(path.relative(root, startAbs)) }] : walk(root, startAbs);
  for await (const f of files) {
    if (match && !match(f.rel)) continue;
    let buf;
    try {
      const st = await fsp.stat(f.abs);
      if (st.size > 1_500_000) continue;
      buf = await fsp.readFile(f.abs);
    } catch {
      continue;
    }
    if (looksBinary(buf)) continue;
    const lines = buf.toString('utf8').split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      if (re.test(lines[i])) {
        out.push(`${f.rel}:${i + 1}: ${lines[i].trim().slice(0, 240)}`);
        if (out.length >= 200) break;
      }
    }
    if (out.length >= 200) break;
  }
  if (!out.length) return 'No matches.';
  return clip(out.join('\n') + (out.length >= 200 ? '\n… (stopped at 200 matches)' : ''));
}

// ----------------------------------------------------------------- edit tools
// Edits are prepared first (so the user can see a diff) and only written on commit.

async function prepareWrite(root, input) {
  if (typeof input.content !== 'string') throw new Error('content must be a string.');
  const abs = resolveInside(root, input.path);
  let old = null;
  try {
    old = await readText(abs);
  } catch (e) {
    if (e.code !== 'ENOENT') throw e;
  }
  const rel = toPosix(path.relative(root, abs));
  const d = diffText(old === null ? '' : old.replace(/\r\n/g, '\n'), input.content.replace(/\r\n/g, '\n'));
  return {
    preview: { kind: 'diff', path: rel, isNew: old === null, diff: d.text, added: d.added, removed: d.removed },
    commit: async () => {
      await fsp.mkdir(path.dirname(abs), { recursive: true });
      await fsp.writeFile(abs, input.content, 'utf8');
      return `${old === null ? 'Created' : 'Overwrote'} ${rel} (${input.content.split('\n').length} lines).`;
    },
  };
}

async function prepareEdit(root, input) {
  const abs = resolveInside(root, input.path);
  const rel = toPosix(path.relative(root, abs));
  let raw;
  try {
    raw = await readText(abs);
  } catch (e) {
    if (e.code === 'ENOENT') throw new Error(`File not found: ${rel}. Use write_file to create it.`);
    throw e;
  }
  const crlf = raw.includes('\r\n');
  const text = raw.replace(/\r\n/g, '\n');
  const oldS = String(input.old_string ?? '').replace(/\r\n/g, '\n');
  const newS = String(input.new_string ?? '').replace(/\r\n/g, '\n');
  if (oldS === '') throw new Error('old_string must not be empty.');
  if (oldS === newS) throw new Error('old_string and new_string are identical.');
  const count = text.split(oldS).length - 1;
  if (count === 0) {
    throw new Error(`old_string was not found in ${rel}. It must match the file exactly, including whitespace. Read the file again and retry.`);
  }
  if (count > 1 && !input.replace_all) {
    throw new Error(`old_string appears ${count} times in ${rel}. Add surrounding lines to make it unique, or set replace_all to true.`);
  }
  const updated = input.replace_all ? text.split(oldS).join(newS) : text.replace(oldS, () => newS);
  const d = diffText(text, updated);
  return {
    preview: { kind: 'diff', path: rel, isNew: false, diff: d.text, added: d.added, removed: d.removed },
    commit: async () => {
      await fsp.writeFile(abs, crlf ? updated.replace(/\n/g, '\r\n') : updated, 'utf8');
      return `Edited ${rel} (${count} replacement${count > 1 ? 's' : ''}, +${d.added} −${d.removed} lines).`;
    },
  };
}

// ----------------------------------------------------------------- exec tools

let bgCounter = 0;

function runCommand(root, input, ctx) {
  const command = String(input.command || '').trim();
  if (!command) throw new Error('command must not be empty.');
  const timeoutMs = Math.min(600, Math.max(1, Number(input.timeout_seconds) || 120)) * 1000;
  const background = !!input.background;

  return new Promise((resolve) => {
    const child = spawn(command, {
      cwd: root,
      shell: true,
      windowsHide: true,
      detached: process.platform !== 'win32',
      env: { ...process.env, NO_COLOR: '1', FORCE_COLOR: '0' },
    });
    let output = '';
    let settled = false;
    let bg = null;
    let timer = null;

    const onData = (chunk) => {
      const s = stripAnsi(chunk.toString('utf8'));
      if (bg) {
        bg.buffer = (bg.buffer + s).slice(-200_000);
      } else {
        output += s;
        if (output.length > 400_000) output = output.slice(-300_000);
        if (ctx.onOutput) ctx.onOutput(s);
      }
    };
    child.stdout.on('data', onData);
    child.stderr.on('data', onData);

    const finish = (text, isError) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (ctx.signal) ctx.signal.removeEventListener('abort', onAbort);
      resolve({ output: clip(text), isError });
    };
    const onAbort = () => {
      killTree(child);
      finish(`${output}\n[Command stopped by the user]`.trim(), true);
    };
    if (ctx.signal) {
      if (ctx.signal.aborted) return onAbort();
      ctx.signal.addEventListener('abort', onAbort, { once: true });
    }

    timer = setTimeout(() => {
      if (background) {
        const id = `bg${++bgCounter}`;
        bg = { id, child, command, buffer: '', exitCode: null };
        ctx.background.set(id, bg);
        finish(`Started in the background as "${id}". Use background_output to read more output or stop it.\n\nOutput so far:\n${output || '(none yet)'}`, false);
      } else {
        killTree(child);
        finish(`${output}\n[Command timed out after ${timeoutMs / 1000}s and was stopped. For servers or watchers use background: true.]`.trim(), true);
      }
    }, background ? 5000 : timeoutMs);

    child.on('error', (e) => finish(`Failed to start command: ${e.message}`, true));
    child.on('close', (code) => {
      if (bg) {
        bg.exitCode = code ?? -1;
        return;
      }
      finish(`${output.trimEnd() || '(no output)'}\n[exit code ${code}]`, code !== 0);
    });
  });
}

function backgroundOutput(input, ctx) {
  const bg = ctx.background.get(String(input.id));
  if (!bg) throw new Error(`No background process with id "${input.id}".`);
  const out = bg.buffer;
  bg.buffer = '';
  let status = bg.exitCode === null ? 'running' : `exited with code ${bg.exitCode}`;
  if (input.kill && bg.exitCode === null) {
    killTree(bg.child);
    status = 'stopped';
  }
  if (bg.exitCode !== null || input.kill) ctx.background.delete(bg.id);
  return clip(`[${bg.id}: ${status}]\n${out || '(no new output)'}`);
}

function killAllBackground(map) {
  for (const bg of map.values()) killTree(bg.child);
  map.clear();
}

// ------------------------------------------------------------------- dispatch

/**
 * Validates a tool call and returns { preview, run }.
 * `preview` describes what will happen (shown in the approval card);
 * `run()` performs it and resolves to { output, isError }.
 */
async function prepareTool(root, name, input, ctx) {
  const wrap = (fn) => async () => {
    try {
      const r = await fn();
      return typeof r === 'string' ? { output: r, isError: false } : r;
    } catch (e) {
      return { output: `Error: ${e.message}`, isError: true };
    }
  };
  switch (name) {
    case 'list_dir':
      return { run: wrap(() => listDir(root, input)) };
    case 'read_file':
      return { run: wrap(() => readFile(root, input)) };
    case 'find_files':
      return { run: wrap(() => findFiles(root, input)) };
    case 'search':
      return { run: wrap(() => search(root, input)) };
    case 'write_file': {
      const p = await prepareWrite(root, input);
      return { preview: p.preview, run: wrap(p.commit) };
    }
    case 'edit_file': {
      const p = await prepareEdit(root, input);
      return { preview: p.preview, run: wrap(p.commit) };
    }
    case 'run_command':
      if (!String(input.command || '').trim()) throw new Error('command must not be empty.');
      return {
        preview: { kind: 'command', command: String(input.command), background: !!input.background },
        run: wrap(() => runCommand(root, input, ctx)),
      };
    case 'background_output':
      return { run: wrap(() => backgroundOutput(input, ctx)) };
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

module.exports = { TOOLS, toolsForMode, prepareTool, killAllBackground, resolveInside, globToRegExp, clip };
