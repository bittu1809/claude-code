'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, safeStorage, Menu } = require('electron');
const path = require('path');
const crypto = require('crypto');
const { Store } = require('./store');
const { PRESETS, resolveProvider, listModels } = require('./providers');
const { runTurn } = require('./agent');
const { killAllBackground } = require('./tools');

if (process.env.TRIMODE_DATA_DIR) app.setPath('userData', process.env.TRIMODE_DATA_DIR);

let win = null;
let store = null;
let settings = null;
const sessions = new Map(); // id -> session kept in memory while the app runs
const background = new Map(); // background processes started by run_command
let active = null; // { sessionId, controller, approvals: Map }

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

function getSession(id) {
  if (!sessions.has(id)) sessions.set(id, store.loadSession(id));
  return sessions.get(id);
}

/** Settings as the renderer sees them: API keys never leave the main process. */
function publicSettings() {
  const providers = {};
  for (const id of Object.keys(PRESETS)) {
    const cfg = resolveProvider(settings, id);
    providers[id] = { label: cfg.label, baseUrl: cfg.baseUrl, model: cfg.model, hasKey: !!cfg.apiKey, needsKey: cfg.needsKey, defaultBaseUrl: PRESETS[id].baseUrl };
  }
  return { provider: settings.provider, maxTokens: settings.maxTokens, lastWorkspace: settings.lastWorkspace, lastMode: settings.lastMode, providers };
}

function createWindow() {
  win = new BrowserWindow({
    width: 1240,
    height: 820,
    minWidth: 760,
    minHeight: 520,
    backgroundColor: '#14161a',
    title: 'Trimode',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  // Links in model output open in the real browser, never inside the app.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  // F12 opens the developer tools (handy when something looks wrong).
  win.webContents.on('before-input-event', (_e, input) => {
    if (input.type === 'keyDown' && input.key === 'F12') win.webContents.toggleDevTools();
  });
  win.on('closed', () => {
    win = null;
  });
}

function registerIpc() {
  ipcMain.handle('init', () => ({
    settings: publicSettings(),
    sessions: store.listSessions(),
    platform: process.platform,
  }));

  // ---- settings

  ipcMain.handle('settings:save', (_e, patch) => {
    if (patch.provider && PRESETS[patch.provider]) settings.provider = patch.provider;
    if (Number.isFinite(patch.maxTokens)) settings.maxTokens = Math.max(1024, Math.min(128000, Math.round(patch.maxTokens)));
    if (typeof patch.lastMode === 'string') settings.lastMode = patch.lastMode;
    for (const [id, p] of Object.entries(patch.providers || {})) {
      if (!PRESETS[id]) continue;
      const cur = settings.providers[id] || (settings.providers[id] = { apiKey: '', baseUrl: '', model: '' });
      if (typeof p.baseUrl === 'string') cur.baseUrl = p.baseUrl.trim() === PRESETS[id].baseUrl ? '' : p.baseUrl.trim();
      if (typeof p.model === 'string') cur.model = p.model.trim();
      if (typeof p.apiKey === 'string') cur.apiKey = p.apiKey.trim(); // only sent when the user typed a new one
    }
    store.saveSettings(settings);
    return publicSettings();
  });

  ipcMain.handle('models:list', async (_e, { id, apiKey, baseUrl }) => {
    const cfg = resolveProvider(settings, id);
    if (typeof apiKey === 'string' && apiKey.trim()) cfg.apiKey = apiKey.trim();
    if (typeof baseUrl === 'string' && baseUrl.trim()) cfg.baseUrl = baseUrl.trim().replace(/\/+$/, '');
    return listModels(cfg);
  });

  // ---- sessions and project folder

  ipcMain.handle('workspace:pick', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose a project folder', properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    settings.lastWorkspace = r.filePaths[0];
    store.saveSettings(settings);
    return r.filePaths[0];
  });

  ipcMain.handle('workspace:open', (_e, dir) => shell.openPath(dir));

  ipcMain.handle('sessions:list', () => store.listSessions());
  ipcMain.handle('sessions:create', (_e, workspace) => {
    const s = store.createSession(workspace || '');
    sessions.set(s.id, s);
    return s;
  });
  ipcMain.handle('sessions:load', (_e, id) => {
    const { allow, ...data } = getSession(id);
    return data;
  });
  ipcMain.handle('sessions:delete', (_e, id) => {
    if (active && active.sessionId === id) active.controller.abort();
    sessions.delete(id);
    store.deleteSession(id);
    return store.listSessions();
  });
  ipcMain.handle('sessions:setWorkspace', (_e, { id, workspace }) => {
    const s = getSession(id);
    s.workspace = workspace;
    if (s.messages.length) store.saveSession(s);
    return true;
  });

  // ---- the agent

  ipcMain.handle('agent:send', async (_e, { sessionId, text, mode }) => {
    if (active) throw new Error('The agent is already working. Stop it first.');
    const session = getSession(sessionId);
    const controller = new AbortController();
    const approvals = new Map();
    active = { sessionId, controller, approvals };
    controller.signal.addEventListener('abort', () => {
      for (const resolve of approvals.values()) resolve({ decision: 'deny', feedback: 'The user stopped the run.' });
      approvals.clear();
    });

    if (!session.messages.length) {
      session.title = text.replace(/\s+/g, ' ').trim().slice(0, 60) || 'New session';
    }
    settings.lastMode = mode;
    const emit = (event) => send('agent:event', { sessionId, ...event });

    try {
      const result = await runTurn({
        session,
        settings,
        mode,
        text,
        emit,
        signal: controller.signal,
        background,
        askApproval: (request) => new Promise((resolve) => {
          const id = crypto.randomUUID();
          approvals.set(id, resolve);
          emit({ type: 'approval', id, ...request });
        }),
      });
      emit({ type: 'done', stopped: result.stopped, usage: result.usage });
    } catch (e) {
      emit({ type: 'error', message: e.message || String(e) });
      emit({ type: 'done', stopped: false, failed: true });
    } finally {
      active = null;
      try {
        store.saveSession(session);
        store.saveSettings(settings);
      } catch (e) {
        emit({ type: 'error', message: `Could not save the session: ${e.message}` });
      }
      send('sessions:changed', store.listSessions());
    }
    return true;
  });

  ipcMain.handle('agent:stop', () => {
    if (active) active.controller.abort();
    return true;
  });

  ipcMain.handle('approval:respond', (_e, { id, decision, feedback }) => {
    const resolve = active && active.approvals.get(id);
    if (!resolve) return false;
    active.approvals.delete(id);
    resolve({ decision: ['allow', 'always', 'deny'].includes(decision) ? decision : 'deny', feedback: String(feedback || '').slice(0, 2000) });
    return true;
  });
}

app.whenReady().then(() => {
  const vault = safeStorage.isEncryptionAvailable()
    ? {
        encrypt: (s) => safeStorage.encryptString(s).toString('base64'),
        decrypt: (s) => safeStorage.decryptString(Buffer.from(s, 'base64')),
      }
    : null;
  store = new Store(app.getPath('userData'), vault);
  settings = store.loadSettings();
  // macOS needs the default menu for copy/paste shortcuts; elsewhere the menu bar is just clutter.
  if (process.platform !== 'darwin') Menu.setApplicationMenu(null);
  registerIpc();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  if (active) active.controller.abort();
  killAllBackground(background);
});
