'use strict';
// The agent loop: send the conversation to the model, run the tools it asks
// for (with approval where required), feed the results back, repeat.

const fs = require('fs');
const { streamChat, resolveProvider } = require('./providers');
const { toolsForMode, prepareTool, clip } = require('./tools');
const { buildSystemPrompt } = require('./prompts');

const MAX_ROUNDS = 80;

/**
 * In Chat mode no tools are sent, so earlier tool activity is folded into
 * plain text; some providers reject tool messages when no tools are declared.
 */
function flattenToolHistory(messages) {
  const out = [];
  for (const m of messages) {
    if (m.role === 'assistant') {
      const calls = (m.toolCalls || []).map((c) => `[used ${c.name}: ${JSON.stringify(c.input || {}).slice(0, 200)}]`);
      out.push({ role: 'assistant', text: [m.text, ...calls].filter(Boolean).join('\n'), toolCalls: [] });
    } else if (m.role === 'tool') {
      const text = m.results.map((r) => `[result of ${r.name}]\n${clip(r.output || '', 1500)}`).join('\n\n');
      out.push({ role: 'user', content: text });
    } else {
      out.push(m);
    }
  }
  return out;
}

function approvalKey(name, input) {
  return name === 'run_command' ? `cmd:${String(input.command).trim()}` : 'edits';
}

/**
 * Runs one user turn to completion.
 *
 * opts:
 *   session        { messages, workspace, allow: Set }   (mutated)
 *   settings       app settings (provider, keys, maxTokens)
 *   mode           'chat' | 'plan' | 'act'
 *   text           the user's message
 *   emit(event)    UI events
 *   askApproval(p) resolves to { decision: 'allow'|'always'|'deny', feedback? }
 *   signal         AbortSignal
 *   background     Map of background processes
 *   fetchImpl      optional fetch override (used by tests)
 */
async function runTurn(opts) {
  const { session, settings, mode, text, emit, askApproval, signal, background, fetchImpl } = opts;
  const provider = resolveProvider(settings);

  if (mode !== 'chat') {
    if (!session.workspace) throw new Error('Choose a project folder first (left sidebar).');
    if (!fs.existsSync(session.workspace)) throw new Error(`Project folder not found: ${session.workspace}`);
  }
  if (!session.allow) session.allow = new Set();

  const tools = toolsForMode(mode);
  const toolByName = new Map(tools.map((t) => [t.name, t]));
  const system = buildSystemPrompt({ mode, workspace: session.workspace });

  session.messages.push({ role: 'user', content: text, mode });
  const total = { input: 0, output: 0 };

  for (let round = 0; round < MAX_ROUNDS; round++) {
    let partial = '';
    let res;
    try {
      res = await streamChat(provider, {
        system,
        messages: tools.length ? session.messages : flattenToolHistory(session.messages),
        tools,
        maxTokens: settings.maxTokens,
        signal,
        onText: (delta) => {
          partial += delta;
          emit({ type: 'text', delta });
        },
        onToolPending: (name) => emit({ type: 'tool_pending', name }),
      }, fetchImpl);
    } catch (e) {
      // Keep whatever was streamed so the transcript and history stay consistent.
      if (partial.trim()) session.messages.push({ role: 'assistant', text: partial, toolCalls: [], mode });
      emit({ type: 'assistant_end' });
      if (e.name === 'AbortError' || signal.aborted) return { stopped: true, usage: total };
      throw e;
    }

    total.input = res.usage.input || total.input;
    total.output += res.usage.output || 0;
    session.messages.push({ role: 'assistant', text: res.text, toolCalls: res.toolCalls, mode });
    emit({ type: 'assistant_end' });

    if (!res.toolCalls.length) {
      if (res.stopReason === 'max_tokens' || res.stopReason === 'length') {
        emit({ type: 'notice', message: 'The reply hit the output limit and was cut off. Say "continue" to carry on, or raise Max output tokens in Settings.' });
      }
      return { stopped: false, usage: total };
    }

    const results = [];
    for (const call of res.toolCalls) {
      let preview = null; // kept with the result so the diff shows again when the session is reopened
      const done = (output, isError) => {
        results.push({ id: call.id, name: call.name, output, isError: !!isError, ...(preview ? { preview } : {}) });
        emit({ type: 'tool_end', callId: call.id, output: clip(output, 12_000), isError: !!isError });
      };
      emit({ type: 'tool_start', callId: call.id, name: call.name, input: call.input || {} });

      if (signal.aborted) {
        done('Interrupted by the user before this ran.', true);
        continue;
      }
      if (call.parseError) {
        done(`Error: ${call.parseError}`, true);
        continue;
      }
      const def = toolByName.get(call.name);
      if (!def) {
        done(`Error: the tool "${call.name}" is not available in ${mode[0].toUpperCase() + mode.slice(1)} mode. ${mode === 'plan' ? 'Changes and commands need Act mode; finish the plan and let the user switch.' : ''}`.trim(), true);
        continue;
      }

      let prepared;
      try {
        prepared = await prepareTool(session.workspace, call.name, call.input, {
          signal,
          background,
          onOutput: (chunk) => emit({ type: 'tool_output', callId: call.id, chunk }),
        });
      } catch (e) {
        done(`Error: ${e.message}`, true);
        continue;
      }
      preview = prepared.preview || null;

      if (def.needsApproval) {
        const key = approvalKey(call.name, call.input);
        if (!session.allow.has(key)) {
          const answer = await askApproval({ callId: call.id, name: call.name, preview: prepared.preview });
          if (answer.decision === 'always') session.allow.add(key);
          if (answer.decision === 'deny') {
            const why = answer.feedback ? ` Their feedback: ${answer.feedback}` : '';
            done(`The user declined this action; nothing was changed.${why}`, true);
            continue;
          }
        } else if (prepared.preview) {
          emit({ type: 'tool_preview', callId: call.id, preview: prepared.preview });
        }
      }

      const r = await prepared.run();
      done(r.output, r.isError);
    }

    session.messages.push({ role: 'tool', results });
    if (signal.aborted) return { stopped: true, usage: total };
  }

  emit({ type: 'notice', message: `Stopped after ${MAX_ROUNDS} tool rounds. Say "continue" to keep going.` });
  return { stopped: false, usage: total };
}

module.exports = { runTurn, flattenToolHistory };
