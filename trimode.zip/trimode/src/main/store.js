'use strict';
// Settings and saved sessions, kept as JSON files in the app's data folder.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULT_SETTINGS = {
  provider: 'anthropic',
  providers: {},
  maxTokens: 16000,
  lastWorkspace: '',
  lastMode: 'chat',
};

class Store {
  /**
   * @param dir   folder to keep data in
   * @param vault optional { encrypt(str) -> base64, decrypt(base64) -> str } for API keys
   */
  constructor(dir, vault) {
    this.dir = dir;
    this.vault = vault || null;
    this.sessionsDir = path.join(dir, 'sessions');
    fs.mkdirSync(this.sessionsDir, { recursive: true });
    this.settingsFile = path.join(dir, 'settings.json');
  }

  // ---- settings

  loadSettings() {
    let raw = {};
    try {
      raw = JSON.parse(fs.readFileSync(this.settingsFile, 'utf8'));
    } catch {}
    const s = { ...DEFAULT_SETTINGS, ...raw, providers: {} };
    for (const [id, p] of Object.entries(raw.providers || {})) {
      const copy = { baseUrl: p.baseUrl || '', model: p.model || '', apiKey: '' };
      if (p.apiKeyEnc && this.vault) {
        try {
          copy.apiKey = this.vault.decrypt(p.apiKeyEnc);
        } catch {}
      } else if (p.apiKey) {
        copy.apiKey = p.apiKey;
      }
      s.providers[id] = copy;
    }
    return s;
  }

  saveSettings(s) {
    const out = { ...s, providers: {} };
    for (const [id, p] of Object.entries(s.providers || {})) {
      const copy = { baseUrl: p.baseUrl || '', model: p.model || '' };
      if (p.apiKey) {
        if (this.vault) copy.apiKeyEnc = this.vault.encrypt(p.apiKey);
        else copy.apiKey = p.apiKey;
      }
      out.providers[id] = copy;
    }
    fs.writeFileSync(this.settingsFile, JSON.stringify(out, null, 2));
  }

  // ---- sessions

  file(id) {
    if (!/^[a-z0-9-]+$/i.test(id)) throw new Error('Bad session id');
    return path.join(this.sessionsDir, `${id}.json`);
  }

  createSession(workspace) {
    const now = Date.now();
    return { id: crypto.randomUUID(), title: 'New session', workspace: workspace || '', messages: [], createdAt: now, updatedAt: now };
  }

  saveSession(session) {
    const { allow, ...data } = session; // approvals granted "for this session" are never persisted
    data.updatedAt = Date.now();
    session.updatedAt = data.updatedAt;
    fs.writeFileSync(this.file(session.id), JSON.stringify(data));
  }

  loadSession(id) {
    return JSON.parse(fs.readFileSync(this.file(id), 'utf8'));
  }

  deleteSession(id) {
    try {
      fs.unlinkSync(this.file(id));
    } catch {}
  }

  listSessions() {
    const out = [];
    for (const f of fs.readdirSync(this.sessionsDir)) {
      if (!f.endsWith('.json')) continue;
      try {
        const s = JSON.parse(fs.readFileSync(path.join(this.sessionsDir, f), 'utf8'));
        out.push({ id: s.id, title: s.title, workspace: s.workspace, updatedAt: s.updatedAt });
      } catch {}
    }
    return out.sort((a, b) => b.updatedAt - a.updatedAt);
  }
}

module.exports = { Store, DEFAULT_SETTINGS };
