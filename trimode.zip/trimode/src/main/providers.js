'use strict';
// Model providers. Two wire formats cover everything:
//   - "anthropic": the Anthropic Messages API
//   - "openai":    the Chat Completions API, which OpenAI, Gemini, OpenRouter,
//                  Ollama, Groq, DeepSeek, LM Studio and most others speak.
//
// Internally the conversation is stored in a neutral shape:
//   { role: 'user', content: string }
//   { role: 'assistant', text: string, toolCalls: [{ id, name, input, extra? }] }
//   { role: 'tool', results: [{ id, name, output, isError }] }

const PRESETS = {
  anthropic: { label: 'Anthropic (Claude)', kind: 'anthropic', baseUrl: 'https://api.anthropic.com', needsKey: true },
  openai: { label: 'OpenAI', kind: 'openai', baseUrl: 'https://api.openai.com/v1', needsKey: true },
  gemini: { label: 'Google Gemini', kind: 'openai', baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai', needsKey: true },
  openrouter: { label: 'OpenRouter', kind: 'openai', baseUrl: 'https://openrouter.ai/api/v1', needsKey: true },
  ollama: { label: 'Ollama (local)', kind: 'openai', baseUrl: 'http://localhost:11434/v1', needsKey: false },
  custom: { label: 'Custom (OpenAI-compatible)', kind: 'openai', baseUrl: '', needsKey: false },
};

/** Merge the saved settings for the active provider with its preset. */
function resolveProvider(settings, id = settings.provider) {
  const preset = PRESETS[id];
  if (!preset) throw new Error(`Unknown provider "${id}". Open Settings and pick one.`);
  const saved = (settings.providers && settings.providers[id]) || {};
  const cfg = {
    id,
    label: preset.label,
    kind: preset.kind,
    baseUrl: (saved.baseUrl || preset.baseUrl || '').replace(/\/+$/, ''),
    apiKey: saved.apiKey || '',
    model: saved.model || '',
    needsKey: preset.needsKey,
  };
  return cfg;
}

function assertReady(cfg) {
  if (!cfg.baseUrl) throw new Error(`No base URL set for ${cfg.label}. Open Settings to add one.`);
  if (cfg.needsKey && !cfg.apiKey) throw new Error(`No API key set for ${cfg.label}. Open Settings to add one.`);
  if (!cfg.model) throw new Error(`No model chosen for ${cfg.label}. Open Settings, click "Load models" and pick one.`);
}

// ------------------------------------------------------------------ transport

const RETRY_STATUS = new Set([408, 409, 429, 500, 502, 503, 504, 529]);

function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    if (signal) {
      signal.addEventListener('abort', () => {
        clearTimeout(t);
        reject(Object.assign(new Error('Aborted'), { name: 'AbortError' }));
      }, { once: true });
    }
  });
}

async function errorFromResponse(res) {
  let detail = '';
  try {
    const raw = await res.text();
    try {
      const j = JSON.parse(raw);
      const e = Array.isArray(j) ? j[0] && j[0].error : j.error;
      detail = (e && (e.message || e.type)) || (typeof j.error === 'string' ? j.error : '') || j.message || raw;
    } catch {
      detail = raw;
    }
  } catch {}
  const err = new Error(`${res.status} ${res.statusText || ''} — ${String(detail).slice(0, 600)}`.trim());
  err.status = res.status;
  return err;
}

async function request(url, init, signal, fetchImpl) {
  let lastErr;
  for (let attempt = 0; attempt < 4; attempt++) {
    let res;
    try {
      res = await fetchImpl(url, { ...init, signal });
    } catch (e) {
      if (e.name === 'AbortError' || (signal && signal.aborted)) throw e;
      lastErr = new Error(`Could not reach ${new URL(url).host}: ${e.cause ? e.cause.message || e.cause.code : e.message}`);
      if (attempt < 3) await sleep(800 * 2 ** attempt, signal);
      continue;
    }
    if (res.ok) return res;
    lastErr = await errorFromResponse(res);
    if (!RETRY_STATUS.has(res.status) || attempt === 3) throw lastErr;
    const retryAfter = Number(res.headers.get('retry-after'));
    await sleep(Math.min(20_000, retryAfter > 0 ? retryAfter * 1000 : 1000 * 2 ** attempt), signal);
  }
  throw lastErr;
}

/** Yields the JSON payload of each `data:` line of a server-sent-event stream. */
async function* sse(res) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  const parse = (line) => {
    if (!line.startsWith('data:')) return undefined;
    const d = line.slice(5).trim();
    if (!d || d === '[DONE]') return undefined;
    try {
      return JSON.parse(d);
    } catch {
      return undefined;
    }
  };
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).replace(/\r$/, '');
      buf = buf.slice(i + 1);
      const j = parse(line);
      if (j !== undefined) yield j;
    }
  }
  const j = parse(buf.trim());
  if (j !== undefined) yield j;
}

function parseArgs(raw) {
  if (!raw || !raw.trim()) return { input: {} };
  try {
    const v = JSON.parse(raw);
    if (v && typeof v === 'object' && !Array.isArray(v)) return { input: v };
    return { input: null, parseError: 'Tool arguments were not a JSON object.' };
  } catch {
    return { input: null, parseError: 'Tool arguments were not valid JSON. The reply was probably cut off by the output limit — try again with smaller pieces.' };
  }
}

// ------------------------------------------------------------------ anthropic

function toAnthropicMessages(messages) {
  const out = [];
  for (const m of messages) {
    if (m.role === 'user') {
      out.push({ role: 'user', content: [{ type: 'text', text: m.content || '(empty)' }] });
    } else if (m.role === 'assistant') {
      const content = [];
      if (m.text && m.text.trim()) content.push({ type: 'text', text: m.text });
      for (const c of m.toolCalls || []) content.push({ type: 'tool_use', id: c.id, name: c.name, input: c.input || {} });
      if (!content.length) content.push({ type: 'text', text: '(no reply)' });
      out.push({ role: 'assistant', content });
    } else if (m.role === 'tool') {
      out.push({
        role: 'user',
        content: m.results.map((r) => ({
          type: 'tool_result',
          tool_use_id: r.id,
          content: r.output || '(no output)',
          ...(r.isError ? { is_error: true } : {}),
        })),
      });
    }
  }
  // Cache the conversation prefix so each agent step only pays for what is new.
  const last = out[out.length - 1];
  if (last) last.content[last.content.length - 1].cache_control = { type: 'ephemeral' };
  return out;
}

async function streamAnthropic(cfg, req, fetchImpl) {
  const body = {
    model: cfg.model,
    max_tokens: req.maxTokens || 16000,
    stream: true,
    system: [{ type: 'text', text: req.system, cache_control: { type: 'ephemeral' } }],
    messages: toAnthropicMessages(req.messages),
  };
  if (req.tools.length) {
    body.tools = req.tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.input_schema }));
  }
  const res = await request(`${cfg.baseUrl}/v1/messages`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify(body),
  }, req.signal, fetchImpl);

  let text = '';
  let stopReason = null;
  const usage = { input: 0, output: 0 };
  const blocks = new Map();
  const toolCalls = [];

  for await (const ev of sse(res)) {
    if (ev.type === 'message_start' && ev.message && ev.message.usage) {
      const u = ev.message.usage;
      usage.input = (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0);
    } else if (ev.type === 'content_block_start') {
      const b = ev.content_block || {};
      if (b.type === 'tool_use') {
        blocks.set(ev.index, { id: b.id, name: b.name, json: '' });
        if (req.onToolPending) req.onToolPending(b.name);
      }
    } else if (ev.type === 'content_block_delta') {
      const d = ev.delta || {};
      if (d.type === 'text_delta' && d.text) {
        text += d.text;
        if (req.onText) req.onText(d.text);
      } else if (d.type === 'input_json_delta') {
        const b = blocks.get(ev.index);
        if (b) b.json += d.partial_json || '';
      }
    } else if (ev.type === 'content_block_stop') {
      const b = blocks.get(ev.index);
      if (b) {
        toolCalls.push({ id: b.id, name: b.name, ...parseArgs(b.json) });
        blocks.delete(ev.index);
      }
    } else if (ev.type === 'message_delta') {
      if (ev.delta && ev.delta.stop_reason) stopReason = ev.delta.stop_reason;
      if (ev.usage && ev.usage.output_tokens) usage.output = ev.usage.output_tokens;
    } else if (ev.type === 'error') {
      throw new Error((ev.error && ev.error.message) || 'The provider reported a streaming error.');
    }
  }
  // Blocks still open here mean the stream was cut off mid tool call.
  for (const b of blocks.values()) toolCalls.push({ id: b.id, name: b.name, ...parseArgs(b.json) });
  return { text, toolCalls, stopReason, usage };
}

// --------------------------------------------------------------------- openai

function toOpenAIMessages(system, messages) {
  const out = [{ role: 'system', content: system }];
  for (const m of messages) {
    if (m.role === 'user') {
      out.push({ role: 'user', content: m.content || '(empty)' });
    } else if (m.role === 'assistant') {
      const msg = { role: 'assistant', content: m.text || null };
      if (m.toolCalls && m.toolCalls.length) {
        msg.tool_calls = m.toolCalls.map((c) => ({
          id: c.id,
          type: 'function',
          function: { name: c.name, arguments: JSON.stringify(c.input || {}) },
          ...(c.extra || {}),
        }));
      } else if (!msg.content) {
        msg.content = '(no reply)';
      }
      out.push(msg);
    } else if (m.role === 'tool') {
      for (const r of m.results) out.push({ role: 'tool', tool_call_id: r.id, content: r.output || '(no output)' });
    }
  }
  return out;
}

async function streamOpenAI(cfg, req, fetchImpl) {
  const body = { model: cfg.model, stream: true, messages: toOpenAIMessages(req.system, req.messages) };
  if (req.tools.length) {
    body.tools = req.tools.map((t) => ({
      type: 'function',
      function: { name: t.name, description: t.description, parameters: t.input_schema },
    }));
  }
  const headers = { 'content-type': 'application/json' };
  if (cfg.apiKey) headers.authorization = `Bearer ${cfg.apiKey}`;
  const res = await request(`${cfg.baseUrl}/chat/completions`, { method: 'POST', headers, body: JSON.stringify(body) }, req.signal, fetchImpl);

  let text = '';
  let stopReason = null;
  const usage = { input: 0, output: 0 };
  const calls = []; // indexed by tool_call index

  for await (const ev of sse(res)) {
    if (ev.error) throw new Error(ev.error.message || 'The provider reported a streaming error.');
    if (ev.usage) {
      usage.input = ev.usage.prompt_tokens || usage.input;
      usage.output = ev.usage.completion_tokens || usage.output;
    }
    const choice = ev.choices && ev.choices[0];
    if (!choice) continue;
    if (choice.finish_reason) stopReason = choice.finish_reason;
    const d = choice.delta || {};
    if (typeof d.content === 'string' && d.content) {
      text += d.content;
      if (req.onText) req.onText(d.content);
    }
    for (const [i, tc] of (d.tool_calls || []).entries()) {
      const idx = Number.isInteger(tc.index) ? tc.index : i;
      let c = calls[idx];
      if (!c) {
        c = calls[idx] = { id: '', name: '', json: '', extra: null };
      }
      if (tc.id) c.id = tc.id;
      const fn = tc.function || {};
      if (fn.name) {
        if (!c.name && req.onToolPending) req.onToolPending(fn.name);
        c.name = fn.name;
      }
      if (typeof fn.arguments === 'string') c.json += fn.arguments;
      // Gemini attaches a thought signature here that must be sent back unchanged.
      if (tc.extra_content) c.extra = { extra_content: tc.extra_content };
    }
  }

  const toolCalls = calls.filter(Boolean).map((c, i) => ({
    id: c.id || `call_${Date.now().toString(36)}_${i}`,
    name: c.name,
    ...parseArgs(c.json),
    ...(c.extra ? { extra: c.extra } : {}),
  }));
  return { text, toolCalls, stopReason, usage };
}

// --------------------------------------------------------------------- public

/**
 * req: { system, messages, tools, maxTokens, signal, onText(delta), onToolPending(name) }
 * resolves to { text, toolCalls, stopReason, usage }
 */
function streamChat(cfg, req, fetchImpl = fetch) {
  assertReady(cfg);
  return cfg.kind === 'anthropic' ? streamAnthropic(cfg, req, fetchImpl) : streamOpenAI(cfg, req, fetchImpl);
}

async function listModels(cfg, fetchImpl = fetch) {
  if (!cfg.baseUrl) throw new Error('Set a base URL first.');
  if (cfg.needsKey && !cfg.apiKey) throw new Error('Enter an API key first.');
  let url;
  let headers;
  if (cfg.kind === 'anthropic') {
    url = `${cfg.baseUrl}/v1/models?limit=1000`;
    headers = { 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' };
  } else {
    url = `${cfg.baseUrl}/models`;
    headers = cfg.apiKey ? { authorization: `Bearer ${cfg.apiKey}` } : {};
  }
  const res = await request(url, { headers }, undefined, fetchImpl);
  const j = await res.json();
  const list = Array.isArray(j) ? j : j.data || j.models || [];
  return list
    .map((m) => String(m.id || m.name || '').replace(/^models\//, ''))
    .filter(Boolean)
    .sort();
}

module.exports = { PRESETS, resolveProvider, streamChat, listModels };
