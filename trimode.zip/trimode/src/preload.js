'use strict';
// The only bridge between the UI and the main process. The renderer gets a
// small, explicit API and no direct access to Node or Electron.
const { contextBridge, ipcRenderer } = require('electron');

const call = (channel) => (arg) => ipcRenderer.invoke(channel, arg);

contextBridge.exposeInMainWorld('api', {
  init: call('init'),
  saveSettings: call('settings:save'),
  listModels: call('models:list'),
  pickWorkspace: call('workspace:pick'),
  openWorkspace: call('workspace:open'),
  listSessions: call('sessions:list'),
  createSession: call('sessions:create'),
  loadSession: call('sessions:load'),
  deleteSession: call('sessions:delete'),
  setWorkspace: call('sessions:setWorkspace'),
  send: call('agent:send'),
  stop: call('agent:stop'),
  respond: call('approval:respond'),
  onEvent: (fn) => ipcRenderer.on('agent:event', (_e, ev) => fn(ev)),
  onSessionsChanged: (fn) => ipcRenderer.on('sessions:changed', (_e, list) => fn(list)),
});
