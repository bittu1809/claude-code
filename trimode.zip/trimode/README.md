# Trimode

A desktop AI coding agent with three modes. No editor, no file tree: you describe what you want and the agent does the typing.

| Mode | What the agent can do | Use it for |
|---|---|---|
| **Chat** | Talk only. No access to your files. | Questions, ideas, explanations |
| **Plan** | Read, list and search your project. Changes nothing. | Getting a step-by-step plan you can approve |
| **Act** | Edit files and run commands, asking before each one. | Building the thing |

Switch modes with **Shift+Tab** or the switcher under the message box. All three modes share one conversation, so a plan made in Plan mode is carried out in Act mode with full context. After a plan, the **Approve plan and build** button switches to Act for you.

## Run it

You need [Node.js](https://nodejs.org) 20 or newer.

```
npm install
npm start
```

The first `npm start` downloads the Electron runtime (about 100 MB), so it takes a minute.

Then, in the app:

1. Click **Settings**, pick a provider, paste your API key, click **Load models** and choose one.
2. Click **Project folder** and choose the folder the agent should work in.
3. Pick a mode and type.

## Providers

Anthropic (Claude), OpenAI, Google Gemini, OpenRouter, Ollama (local, no key) and any other OpenAI-compatible server through **Custom**. Each provider keeps its own key and model, so you can switch between them in Settings.

Agentic coding needs a model that supports tool calling. Small local models often do not handle it well.

## Safety

- The agent can only touch files inside the project folder you chose. Paths outside it are refused.
- In Act mode every file change shows a diff and every command shows the exact command line before it runs. You can **Allow**, **Deny** (with a note telling the agent what to do instead), allow all edits for the session, or always allow one specific command.
- Commands run with your user account's permissions, in the project folder. Read them before you allow them.
- API keys stay in the app's main process and are saved encrypted with the operating system's keychain where available. Requests go straight from your computer to the provider you chose.
- **Esc** or the **Stop** button interrupts the agent, including a running command.

## Good to know

- Put an `AGENTS.md` (or `CLAUDE.md`) file in your project root to give the agent standing instructions; it is read in Plan and Act mode.
- Sessions are saved automatically and listed in the sidebar.
- Dev servers and other commands that never exit are started in the background by the agent and stopped when you quit the app.
- Long conversations are sent in full each turn. If one gets slow or expensive, start a new session.
- **F12** opens the developer tools.

## Build an installer

```
npm run dist
```

Produces a Windows installer, macOS dmg or Linux AppImage in `dist/`, depending on the system you run it on.

## Tests

```
npm test
```

Runs the tools and the agent loop against a scripted fake provider. No network or API key needed.

## Layout

```
src/main/main.js       window, IPC, wiring
src/main/agent.js      the Chat / Plan / Act loop and approvals
src/main/providers.js  Anthropic and OpenAI-compatible streaming
src/main/tools.js      file, search and shell tools, confined to the project folder
src/main/prompts.js    the system prompt for each mode
src/main/store.js      settings and saved sessions
src/main/diff.js       diff shown in approval cards
src/preload.js         the only bridge between UI and main process
src/renderer/          the UI (plain HTML, CSS and JavaScript, no build step)
```

To rename the app, change `productName` in `package.json`, the window title in `src/main/main.js` and the name in `src/renderer/index.html` and `src/main/prompts.js`.
