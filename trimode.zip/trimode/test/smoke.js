'use strict';
// End-to-end check of the tools and the agent loop against a scripted fake
// provider (no network, no API key). Run with: npm test

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { prepareTool, toolsForMode, killAllBackground } = require('../src/main/tools');
const { runTurn } = require('../src/main/agent');
const { Store } = require('../src/main/store');
const { diffText } = require('../src/main/diff');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'trimode-test-'));
const ws = path.join(tmp, 'project');
fs.mkdirSync(path.join(ws, 'src'), { recursive: true });
fs.mkdirSync(path.join(ws, 'node_modules', 'junk'), { recursive: true });
fs.writeFileSync(path.join(ws, 'src', 'app.js'), 'const a = 1;\r\nconst b = 2;\r\nconsole.log(a + b);\r\n');
fs.writeFileSync(path.join(ws, 'README.md'), '# Demo\nhello world\n');
fs.writeFileSync(path.join(ws, 'node_modules', 'junk', 'x.js'), 'hello world');

let passed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  ok  ${name}`);
  } catch (e) {
    console.error(`FAIL  ${name}\n${e.stack}`);
    process.exitCode = 1;
  }
}

const ctx = () => ({ signal: new AbortController().signal, background: new Map() });
const call = async (name, input, c = ctx()) => (await prepareTool(ws, name, input, c)).run();

// ---- fake provider plumbing

function sseResponse(events) {
  const enc = new TextEncoder();
  const body = new ReadableStream({
    start(controller) {
      // Split awkwardly on purpose to exercise the stream parser.
      const text = events.map((e) => `data: ${JSON.stringify(e)}\n\n`).join('') + 'data: [DONE]\n\n';
      for (let i = 0; i < text.length; i += 37) controller.enqueue(enc.encode(text.slice(i, i + 37)));
      controller.close();
    },
  });
  return new Response(body, { status: 200, headers: { 'content-type': 'text/event-stream' } });
}

function anthropicReply({ text, tools = [] }) {
  const ev = [{ type: 'message_start', message: { usage: { input_tokens: 10 } } }];
  let i = 0;
  if (text) {
    ev.push({ type: 'content_block_start', index: i, content_block: { type: 'text', text: '' } });
    for (const part of text.match(/.{1,9}/gs)) ev.push({ type: 'content_block_delta', index: i, delta: { type: 'text_delta', text: part } });
    ev.push({ type: 'content_block_stop', index: i++ });
  }
  for (const t of tools) {
    ev.push({ type: 'content_block_start', index: i, content_block: { type: 'tool_use', id: t.id, name: t.name, input: {} } });
    for (const part of JSON.stringify(t.input).match(/.{1,11}/gs)) ev.push({ type: 'content_block_delta', index: i, delta: { type: 'input_json_delta', partial_json: part } });
    ev.push({ type: 'content_block_stop', index: i++ });
  }
  ev.push({ type: 'message_delta', delta: { stop_reason: tools.length ? 'tool_use' : 'end_turn' }, usage: { output_tokens: 5 } });
  ev.push({ type: 'message_stop' });
  return ev;
}

function openaiReply({ text, tools = [] }) {
  const ev = [];
  if (text) for (const part of text.match(/.{1,9}/gs)) ev.push({ choices: [{ delta: { content: part } }] });
  tools.forEach((t, index) => {
    ev.push({ choices: [{ delta: { tool_calls: [{ index, id: t.id, type: 'function', function: { name: t.name, arguments: '' }, extra_content: { google: { thought_signature: 'sig' } } }] } }] });
    for (const part of JSON.stringify(t.input).match(/.{1,11}/gs)) ev.push({ choices: [{ delta: { tool_calls: [{ index, function: { arguments: part } }] } }] });
  });
  ev.push({ choices: [{ delta: {}, finish_reason: tools.length ? 'tool_calls' : 'stop' }] });
  return ev;
}

function fakeFetch(script, format, log) {
  let n = 0;
  return async (url, init) => {
    log.push({ url, body: JSON.parse(init.body) });
    const step = script[n++];
    assert(step, 'provider was called more times than scripted');
    return sseResponse(format(step));
  };
}

function harness({ provider, script, format, decide }) {
  const log = [];
  const events = [];
  const settings = {
    provider,
    maxTokens: 4000,
    providers: { [provider]: { apiKey: 'test-key', model: 'test-model', baseUrl: provider === 'custom' ? 'http://fake.local/v1' : '' } },
  };
  const session = { id: 't', messages: [], workspace: ws };
  const approvals = [];
  const run = (mode, text) => runTurn({
    session, settings, mode, text,
    emit: (e) => events.push(e),
    askApproval: async (p) => {
      approvals.push(p);
      return decide(p);
    },
    signal: new AbortController().signal,
    background: new Map(),
    fetchImpl: fakeFetch(script, format, log),
  });
  return { run, log, events, session, approvals };
}

(async () => {
  console.log('tools');

  await test('paths outside the project are rejected', async () => {
    await assert.rejects(() => prepareTool(ws, 'read_file', { path: '../secret.txt' }, ctx()).then((p) => p.run()).then((r) => { if (r.isError) throw new Error(r.output); }), /outside the project/);
    await assert.rejects(() => prepareTool(ws, 'write_file', { path: path.join(tmp, 'evil.txt'), content: 'x' }, ctx()), /outside the project/);
    assert(!fs.existsSync(path.join(tmp, 'evil.txt')));
  });

  await test('list_dir, read_file, find_files, search', async () => {
    assert.match((await call('list_dir', { path: '.' })).output, /src\/\nREADME\.md/);
    const r = await call('read_file', { path: 'src/app.js' });
    assert.match(r.output, /1\tconst a = 1;\n2\tconst b = 2;/);
    assert.strictEqual((await call('find_files', { pattern: '**/*.js' })).output, 'src/app.js');
    assert.strictEqual((await call('find_files', { pattern: '*.md' })).output, 'README.md');
    const s = await call('search', { pattern: 'hello\\s+world' });
    assert.strictEqual(s.output, 'README.md:2: hello world'); // node_modules skipped
  });

  await test('edit_file previews a diff, keeps CRLF, rejects ambiguous edits', async () => {
    const p = await prepareTool(ws, 'edit_file', { path: 'src/app.js', old_string: 'const b = 2;', new_string: 'const b = 40;' }, ctx());
    assert.strictEqual(p.preview.kind, 'diff');
    assert.match(p.preview.diff, /-const b = 2;\n\+const b = 40;/);
    assert.match(fs.readFileSync(path.join(ws, 'src/app.js'), 'utf8'), /const b = 2;/, 'nothing written before commit');
    const r = await p.run();
    assert(!r.isError);
    assert.strictEqual(fs.readFileSync(path.join(ws, 'src/app.js'), 'utf8'), 'const a = 1;\r\nconst b = 40;\r\nconsole.log(a + b);\r\n');
    await assert.rejects(() => prepareTool(ws, 'edit_file', { path: 'src/app.js', old_string: 'const', new_string: 'let' }, ctx()), /appears 2 times/);
    await assert.rejects(() => prepareTool(ws, 'edit_file', { path: 'src/app.js', old_string: 'nope', new_string: 'x' }, ctx()), /not found/);
  });

  await test('write_file creates parent folders', async () => {
    const p = await prepareTool(ws, 'write_file', { path: 'lib/deep/new.txt', content: 'one\ntwo\n' }, ctx());
    assert(p.preview.isNew);
    await p.run();
    assert.strictEqual(fs.readFileSync(path.join(ws, 'lib/deep/new.txt'), 'utf8'), 'one\ntwo\n');
  });

  await test('run_command returns output and exit code, runs in the project', async () => {
    const ok = await call('run_command', { command: 'node -e "console.log(require(\'fs\').existsSync(\'README.md\'))"' });
    assert.match(ok.output, /true\n\[exit code 0\]/);
    const bad = await call('run_command', { command: 'node -e "process.exit(3)"' });
    assert(bad.isError);
    assert.match(bad.output, /exit code 3/);
  });

  await test('run_command times out and can be stopped', async () => {
    const t = await call('run_command', { command: 'node -e "setTimeout(()=>{},60000)"', timeout_seconds: 1 });
    assert(t.isError);
    assert.match(t.output, /timed out/);
    const ac = new AbortController();
    const c = { signal: ac.signal, background: new Map() };
    setTimeout(() => ac.abort(), 300);
    const s = await call('run_command', { command: 'node -e "setTimeout(()=>{},60000)"' }, c);
    assert.match(s.output, /stopped by the user/);
  });

  await test('background commands keep running and can be read and killed', async () => {
    const c = ctx();
    const r = await call('run_command', { command: 'node -e "console.log(\'up\');setInterval(()=>console.log(\'tick\'),500)"', background: true }, c);
    assert.match(r.output, /Started in the background as "bg1"/);
    assert.match(r.output, /up/);
    await new Promise((res) => setTimeout(res, 800));
    const o = await call('background_output', { id: 'bg1', kill: true }, c);
    assert.match(o.output, /tick/);
    assert.strictEqual(c.background.size, 0);
    killAllBackground(c.background);
  });

  await test('mode decides which tools exist', () => {
    assert.deepStrictEqual(toolsForMode('chat'), []);
    assert(toolsForMode('plan').every((t) => t.kind === 'read'));
    assert(toolsForMode('act').some((t) => t.name === 'run_command'));
  });

  await test('diff is compact', () => {
    const a = Array.from({ length: 50 }, (_, i) => `line ${i}`).join('\n');
    const d = diffText(a, a.replace('line 25', 'LINE 25'));
    assert.strictEqual(d.added, 1);
    assert.strictEqual(d.removed, 1);
    assert(d.text.split('\n').length <= 9);
  });

  console.log('agent loop');

  await test('chat mode sends no tools', async () => {
    const h = harness({ provider: 'anthropic', format: anthropicReply, script: [{ text: 'Hi there.' }] });
    await h.run('chat', 'hello');
    assert.strictEqual(h.log[0].url, 'https://api.anthropic.com/v1/messages');
    assert.strictEqual(h.log[0].body.tools, undefined);
    assert.match(h.log[0].body.system[0].text, /Mode: CHAT/);
    assert.strictEqual(h.session.messages[1].text, 'Hi there.');
    assert.strictEqual(h.events.filter((e) => e.type === 'text').map((e) => e.delta).join(''), 'Hi there.');
  });

  await test('plan mode can read but not write', async () => {
    const h = harness({
      provider: 'anthropic',
      format: anthropicReply,
      decide: () => assert.fail('plan mode must never ask for approval'),
      script: [
        { text: 'Looking.', tools: [{ id: 'a1', name: 'read_file', input: { path: 'README.md' } }, { id: 'a2', name: 'write_file', input: { path: 'hack.txt', content: 'x' } }] },
        { text: '1. Do the thing.' },
      ],
    });
    await h.run('plan', 'plan a change');
    assert.deepStrictEqual(h.log[0].body.tools.map((t) => t.name), ['list_dir', 'read_file', 'find_files', 'search']);
    const results = h.session.messages[2].results;
    assert.match(results[0].output, /# Demo/);
    assert(results[1].isError);
    assert.match(results[1].output, /not available in Plan mode/);
    assert(!fs.existsSync(path.join(ws, 'hack.txt')));
    // The second request carries the tool results back in Anthropic's format.
    const sent = h.log[1].body.messages;
    assert.strictEqual(sent[2].content[0].type, 'tool_result');
    assert.strictEqual(sent[2].content[0].tool_use_id, 'a1');
  });

  await test('act mode asks first: allow, deny with feedback, always', async () => {
    const h = harness({
      provider: 'anthropic',
      format: anthropicReply,
      decide: (p) => {
        if (p.name === 'write_file' && p.preview.path === 'notes.txt') return { decision: 'always' };
        if (p.name === 'run_command') return { decision: 'deny', feedback: 'no deleting' };
        return { decision: 'allow' };
      },
      script: [
        { tools: [{ id: 'b1', name: 'write_file', input: { path: 'notes.txt', content: 'v1\n' } }] },
        { tools: [{ id: 'b2', name: 'run_command', input: { command: 'rm -rf src' } }, { id: 'b3', name: 'edit_file', input: { path: 'notes.txt', old_string: 'v1', new_string: 'v2' } }] },
        { text: 'Done.' },
      ],
    });
    await h.run('act', 'make notes');
    assert.strictEqual(fs.readFileSync(path.join(ws, 'notes.txt'), 'utf8'), 'v2\n');
    assert(fs.existsSync(path.join(ws, 'src')), 'denied command must not run');
    assert.strictEqual(h.approvals.length, 2, 'the edit after "always" is not asked again');
    const denied = h.session.messages[4].results[0];
    assert(denied.isError);
    assert.match(denied.output, /declined.*no deleting/);
    assert.strictEqual(h.session.messages.at(-1).text, 'Done.');
  });

  await test('OpenAI-style providers: chunked tool arguments and extras round-trip', async () => {
    const h = harness({
      provider: 'custom',
      format: openaiReply,
      decide: () => ({ decision: 'allow' }),
      script: [
        { text: 'Writing.', tools: [{ id: 'c1', name: 'write_file', input: { path: 'o.txt', content: 'from "openai"\n' } }] },
        { text: 'Finished.' },
      ],
    });
    await h.run('act', 'write o.txt');
    assert.strictEqual(h.log[0].url, 'http://fake.local/v1/chat/completions');
    assert.strictEqual(h.log[0].body.tools[0].type, 'function');
    assert.strictEqual(fs.readFileSync(path.join(ws, 'o.txt'), 'utf8'), 'from "openai"\n');
    const sent = h.log[1].body.messages;
    assert.strictEqual(sent[2].tool_calls[0].extra_content.google.thought_signature, 'sig');
    assert.strictEqual(sent[3].role, 'tool');
    assert.strictEqual(sent[3].tool_call_id, 'c1');
  });

  await test('switching back to chat folds tool history into text', async () => {
    const h = harness({
      provider: 'anthropic',
      format: anthropicReply,
      decide: () => ({ decision: 'allow' }),
      script: [{ tools: [{ id: 'd1', name: 'list_dir', input: { path: '.' } }] }, { text: 'Listed.' }, { text: 'Sure.' }],
    });
    await h.run('plan', 'look around');
    await h.run('chat', 'thanks');
    const body = h.log[2].body;
    assert.strictEqual(body.tools, undefined);
    assert(body.messages.every((m) => m.content.every((b) => b.type === 'text')));
  });

  await test('stopping mid-reply keeps the partial text and a valid history', async () => {
    const ac = new AbortController();
    const fetchImpl = async (_url, init) => {
      const enc = new TextEncoder();
      const ev = { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: 'Half a' } };
      return new Response(new ReadableStream({
        start(c) {
          c.enqueue(enc.encode(`data: ${JSON.stringify(ev)}\n\n`));
          init.signal.addEventListener('abort', () => c.error(Object.assign(new Error('aborted'), { name: 'AbortError' })));
          setTimeout(() => ac.abort(), 50);
        },
      }), { status: 200 });
    };
    const session = { id: 's', messages: [], workspace: ws };
    const r = await runTurn({
      session, mode: 'chat', text: 'go', emit: () => {}, askApproval: async () => ({ decision: 'deny' }),
      settings: { provider: 'anthropic', providers: { anthropic: { apiKey: 'k', model: 'm' } } },
      signal: ac.signal, background: new Map(), fetchImpl,
    });
    assert.strictEqual(r.stopped, true);
    assert.deepStrictEqual(session.messages.map((m) => m.role), ['user', 'assistant']);
    assert.strictEqual(session.messages[1].text, 'Half a');
  });

  await test('provider errors surface with the server message', async () => {
    const fetchImpl = async () => new Response(JSON.stringify({ error: { message: 'invalid x-api-key' } }), { status: 401 });
    const session = { id: 'e', messages: [], workspace: ws };
    await assert.rejects(() => runTurn({
      session, mode: 'chat', text: 'go', emit: () => {}, askApproval: async () => ({ decision: 'deny' }),
      settings: { provider: 'anthropic', providers: { anthropic: { apiKey: 'bad', model: 'm' } } },
      signal: new AbortController().signal, background: new Map(), fetchImpl,
    }), /401.*invalid x-api-key/);
    await assert.rejects(() => runTurn({
      session, mode: 'chat', text: 'go', emit: () => {}, askApproval: async () => ({ decision: 'deny' }),
      settings: { provider: 'openai', providers: {} },
      signal: new AbortController().signal, background: new Map(), fetchImpl,
    }), /No API key set for OpenAI/);
  });

  await test('settings and sessions persist; keys go through the vault', async () => {
    const vault = { encrypt: (s) => Buffer.from(s).toString('base64'), decrypt: (s) => Buffer.from(s, 'base64').toString() };
    const store = new Store(path.join(tmp, 'data'), vault);
    const s = store.loadSettings();
    s.providers.openai = { apiKey: 'sk-secret', model: 'm', baseUrl: '' };
    store.saveSettings(s);
    assert(!fs.readFileSync(store.settingsFile, 'utf8').includes('sk-secret'));
    assert.strictEqual(store.loadSettings().providers.openai.apiKey, 'sk-secret');
    const sess = store.createSession(ws);
    sess.messages.push({ role: 'user', content: 'hi' });
    sess.allow = new Set(['edits']);
    store.saveSession(sess);
    assert.strictEqual(store.listSessions().length, 1);
    assert.strictEqual(store.loadSession(sess.id).allow, undefined);
  });

  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(process.exitCode ? '\nSome tests failed.' : `\nAll ${passed} tests passed.`);
})();
